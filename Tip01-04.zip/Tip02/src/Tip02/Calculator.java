
package Tip02;

public class Calculator {
    public double tax = .05;
    public double tip = .15;  //Change tax and tip if you prefer different values
    public double originalPrice[] = {10.0, 12.0, 9.0, 8.0, 7.0, 15.0, 11.0, 30.0};
    public double taxAndTip = 1.20;
    public double totalPersonal = 0;
    
    public void findTotal(){
        //Calculate an individual's total after tax and tip
        for(int i = 0; i <= originalPrice.length; i++){
            totalPersonal =+ originalPrice[i] * taxAndTip;
            System.out.println("El total persona " + i + " es : " + totalPersonal);
        }

    }
}
