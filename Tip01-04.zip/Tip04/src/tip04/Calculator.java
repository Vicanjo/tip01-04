
package tip04;

public class Calculator {
    public double tax = .05;
    public double tip = .15;
    public double originalPrice[] = {10.0, 12.0, 9.0, 8.0, 7.0, 15.0, 11.0, 30.0};
    double total = 0;
    //Include the cost of Alex's and Forgetful's meals in your calculations
    //Return the total after calculating
    public double totalSinNada(){
        double total = 0;
        for(int i = 0; i < originalPrice.length; i++){
           total =+ originalPrice[i] + total;
        }
        return total;
    }
    public void findTotal(double price, String name){
        double total = price*(1+tax+tip);
        System.out.println(name +": $" +total);
        
    }
    public double pagoPorPersona(){
        double suma = 0;
        for(int i = 0; i < originalPrice.length; i++){
            suma =+ originalPrice[i] + suma;
        }
        suma = suma * 1.20;
        return suma / 6.0;
     }
}
